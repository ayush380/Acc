//SuperClass for type of Question. Can be Extended for other types like textBox.
function Question(question){
  this.title=question.title;
  this.id=question.id;
  this.type=question.type;
  this.answer;
  Question.no=Question.no+1;
}