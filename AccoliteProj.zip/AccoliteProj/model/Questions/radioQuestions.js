// Radio question constructor inherits type Question
function createRadioQuestion(question){
  Question.call(this,question);
  this.noOfOptions=question.options.length;
  this.options=question.options;
}
createRadioQuestion.prototype=Object.create(Question.prototype);