//factory class for type of question. Can be modified to add other types of questions.
function questionsFactory(questions){
    if(questions.type=='radiogroup')
    return new createRadioQuestion(questions);
    if(questions.type=='dropdown')
    return new createDropdownQuestion(questions);
}

