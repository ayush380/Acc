//Class for manipulating data
function Model(data) {
  console.log("in model")
  this.data = data;
  this.currentQuestion = 0;
  this.length = data.questions.length;
  this.questionSet = data.questions;
  
  //function to get Current Question
  this.getQuestion = function() {
    quest= new questionsFactory(this.questionSet[this.currentQuestion]);
    obj={
      quest:quest,
      i:this.currentQuestion
    }
    return obj;
  };
  
  //function to get Next Question
  this.getNextQuestion = function() {
    if (this.isNext()) {
      this.currentQuestion++;
      return this.getQuestion();
    } else return false;
  };
  
  //function to test whether next question exists or not
  this.isNext = function() {
    if (this.currentQuestion >= this.length-1) return false;
    return true;
  };
  
  //function to get Previous Question
  this.getPrevQuestion = function() {
    if(this.isPrev){
    this.currentQuestion--;
    return this.getQuestion();
    }
  };
  
  //function to test whether previous question exists or not
  this.isPrev = function() {
    if (this.currentQuestion <= 0) return false;
    return true;
  };
}
