//controller class for fetching data from model and populating it on view

function Controller(){
  rootElement=document.getElementById('Questionaire');
  console.log("in Controller");
  RawData=new createData();
  this.data=RawData.getData();
  this.model= new Model(this.data);
  this.len=this.model.length;
  this.view=new View(rootElement);
  
  //to create all the questions on the HTML page
  this.createQuestions= function(){
	  ques=this.model.getQuestion().quest;
	  this.view.divForQuestion(ques,0);
	  for(i=0;i<this.len-1;i++){
		  ret=this.model.getNextQuestion();
		  if(ret==false) return false;
		  question=ret.quest;
		  this.view.divForQuestion(question,i+1);
	  }
	  console.log("EXITING");
	  return true;
  }
}