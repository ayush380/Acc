//class to create a view on index.html
function View(rootElement) {
  element=rootElement;
  
  //function to create divs for Questions recieved from controller.
  this.divForQuestion = function(question,i) {
    div = document.createElement('div');
    div.classList.add('tab');
    let id = 'tab' + '_' + i;
    div.setAttribute('id', id);
	div.setAttribute('name',id);
    questionText = document.createElement('p');
    questionText.innerHTML = question.title;
    div.appendChild(questionText);
    div=populateOptions(div,question);
    div.appendChild(document.createElement('br'));
    console.log('in View');
    btn=document.getElementById('prevBtn');
    element.insertBefore(div,btn);
  }
}

